import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/models/user_model.dart';
import '../../../shared/data/user_repository.dart';

/// ─── User Provider ─────────────────────────────────────────────────────────
/// Exposes the current [UserModel] from the local Hive store.
/// Returns `null` when no user is saved (e.g. during onboarding).

final userProvider = Provider<UserModel?>((ref) {
  return ref.read(userRepositoryProvider).getUser();
});

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/models/workout_model.dart';
import '../../../shared/data/workout_repository.dart';

/// ─── Workout Controller ────────────────────────────────────────────────────
/// Exposes the workout plan from the local Hive store.

class WorkoutController extends StateNotifier<List<WorkoutModel>> {
  WorkoutController(this._repo) : super(_repo.getWorkouts());

  final WorkoutRepository _repo;

  /// Force reload from Hive.
  void refresh() {
    state = _repo.getWorkouts();
  }
}

/// ─── Provider ──────────────────────────────────────────────────────────────
final workoutControllerProvider =
    StateNotifierProvider<WorkoutController, List<WorkoutModel>>((ref) {
      final repo = ref.read(workoutRepositoryProvider);
      return WorkoutController(repo);
    });

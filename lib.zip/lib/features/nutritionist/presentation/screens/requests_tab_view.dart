import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/app_theme.dart';
import '../widgets/request_card_widget.dart';

/// ─── Requests Tab View ─────────────────────────────────────────────────────
/// List of incoming user requests with Accept / Decline.

class RequestsTabView extends StatefulWidget {
  const RequestsTabView({super.key});

  @override
  State<RequestsTabView> createState() => _RequestsTabViewState();
}

class _RequestsTabViewState extends State<RequestsTabView> {
  // Mock requests
  final List<_Req> _requests = [
    _Req('Alex Johnson', 'Lose Weight', 25, 82.5),
    _Req('Mona Adel', 'Build Muscle', 28, 65.0),
    _Req('Youssef Ali', 'Maintain', 32, 78.0),
    _Req('Sara Mahmoud', 'Lose Weight', 22, 70.5),
  ];

  void _accept(int i) {
    setState(() => _requests.removeAt(i));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Request accepted!'),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _decline(int i) {
    setState(() => _requests.removeAt(i));
  }

  @override
  Widget build(BuildContext context) {
    if (_requests.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inbox_rounded,
              size: 56,
              color: AppColors.primary.withOpacity(0.3),
            ),
            const SizedBox(height: 12),
            Text(
              'No pending requests',
              style: GoogleFonts.poppins(
                fontSize: 15,
                color: AppColors.textHint,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: _requests.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final r = _requests[i];
        return RequestCardWidget(
          userName: r.name,
          goal: r.goal,
          age: r.age,
          weight: r.weight,
          onAccept: () => _accept(i),
          onDecline: () => _decline(i),
        );
      },
    );
  }
}

class _Req {
  _Req(this.name, this.goal, this.age, this.weight);
  final String name, goal;
  final int age;
  final double weight;
}

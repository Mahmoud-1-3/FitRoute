import 'package:flutter/material.dart';

import '../widgets/client_card_widget.dart';

/// ─── Clients Tab View ──────────────────────────────────────────────────────
/// List of active clients the nutritionist is coaching.

class ClientsTabView extends StatelessWidget {
  const ClientsTabView({super.key});

  static const _clients = [
    _Client('Mohamed Hassan', 78.5, 'Lose Weight', 8),
    _Client('Nour Ahmed', 62.0, 'Build Muscle', 12),
    _Client('Fatma Ali', 70.2, 'Maintain', 4),
    _Client('Khaled Mostafa', 90.0, 'Lose Weight', 16),
    _Client('Rania Sayed', 55.8, 'Build Muscle', 6),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: _clients.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final c = _clients[i];
        return ClientCardWidget(
          name: c.name,
          currentWeight: c.weight,
          goal: c.goal,
          weeksActive: c.weeks,
          onMessage: () => debugPrint('Message ${c.name}'),
        );
      },
    );
  }
}

class _Client {
  const _Client(this.name, this.weight, this.goal, this.weeks);
  final String name, goal;
  final double weight;
  final int weeks;
}

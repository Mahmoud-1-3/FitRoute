import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/app_theme.dart';
import '../widgets/nutritionist_card_widget.dart';

/// ─── Nutritionist Marketplace Screen ───────────────────────────────────────
/// Search bar + filterable list of nutritionists for the User role.

class NutritionistMarketplaceScreen extends StatefulWidget {
  const NutritionistMarketplaceScreen({super.key});

  @override
  State<NutritionistMarketplaceScreen> createState() =>
      _NutritionistMarketplaceScreenState();
}

class _NutritionistMarketplaceScreenState
    extends State<NutritionistMarketplaceScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  // Mock nutritionists
  static const _nutritionists = [
    _Nutri(
      'Dr. Sarah Jenkins',
      'Weight Loss',
      4.9,
      48,
      50,
      '10+ years in clinical nutrition. Specializes in sustainable weight management and metabolic health.',
    ),
    _Nutri(
      'Ahmed El-Masry',
      'Sports Nutrition',
      4.8,
      35,
      45,
      'Former athlete turned sports dietitian. Expert in performance fueling and muscle recovery nutrition.',
    ),
    _Nutri(
      'Dr. Layla Hassan',
      'Clinical Nutrition',
      4.7,
      62,
      60,
      'Board-certified clinical nutritionist. Specializes in hormonal balance and autoimmune protocols.',
    ),
    _Nutri(
      'Omar Farouk',
      'Meal Planning',
      4.6,
      28,
      35,
      'Creative meal planner focused on budget-friendly, high-protein meals for busy professionals.',
    ),
    _Nutri(
      'Dr. Nadia Khalil',
      'Vegan Nutrition',
      4.9,
      41,
      55,
      'Plant-based nutrition expert. Helps clients transition to vegan diets without nutrient deficiencies.',
    ),
    _Nutri(
      'Karim Mostafa',
      'Body Recomposition',
      4.5,
      22,
      40,
      'Fitness-focused dietitian specializing in simultaneous fat loss and muscle gain programs.',
    ),
  ];

  List<_Nutri> get _filtered => _query.isEmpty
      ? _nutritionists
      : _nutritionists
            .where(
              (n) =>
                  n.name.toLowerCase().contains(_query) ||
                  n.specialty.toLowerCase().contains(_query),
            )
            .toList();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final list = _filtered;

    return Scaffold(
      backgroundColor: AppColors.scaffoldBg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header ──
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Text(
                'Find a Nutritionist',
                style: GoogleFonts.poppins(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Browse verified professionals',
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── Search bar ──
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppSizes.radiusFull),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.shadow,
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _query = v.toLowerCase()),
                  style: GoogleFonts.poppins(fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Search by name or specialty…',
                    hintStyle: GoogleFonts.poppins(
                      fontSize: 13,
                      color: AppColors.textHint,
                    ),
                    prefixIcon: const Icon(Icons.search_rounded, size: 22),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.tune_rounded, size: 20),
                      onPressed: () => debugPrint('Open filters'),
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── List ──
            Expanded(
              child: list.isEmpty
                  ? Center(
                      child: Text(
                        'No nutritionists found',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: AppColors.textHint,
                        ),
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (_, i) {
                        final n = list[i];
                        return NutritionistCardWidget(
                          name: n.name,
                          specialty: n.specialty,
                          rating: n.rating,
                          clients: n.clients,
                          pricePerMonth: n.price,
                          onViewProfile: () => context.push(
                            '/nutritionist-profile',
                            extra: {
                              'name': n.name,
                              'specialty': n.specialty,
                              'rating': n.rating,
                              'clients': n.clients,
                              'price': n.price,
                              'bio': n.bio,
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Nutri {
  const _Nutri(
    this.name,
    this.specialty,
    this.rating,
    this.clients,
    this.price,
    this.bio,
  );
  final String name, specialty, bio;
  final double rating;
  final int clients, price;
}

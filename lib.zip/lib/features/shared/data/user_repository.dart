import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../../core/models/user_model.dart';
import '../../../core/services/local_storage_service.dart';

/// ─── User Repository ───────────────────────────────────────────────────────
/// Abstracts Hive CRUD for the logged-in user profile.

class UserRepository {
  UserRepository(this._box);
  final Box<UserModel> _box;

  static const String _key = 'current_user';

  /// Persist the current user.
  Future<void> saveUser(UserModel user) async {
    await _box.put(_key, user);
  }

  /// Retrieve the current user (or null if not set).
  UserModel? getUser() {
    return _box.get(_key);
  }

  /// Remove the current user (logout).
  Future<void> deleteUser() async {
    await _box.delete(_key);
  }
}

/// ─── Provider ──────────────────────────────────────────────────────────────
final userRepositoryProvider = Provider<UserRepository>((ref) {
  final box = Hive.box<UserModel>(LocalStorageService.userBox);
  return UserRepository(box);
});
